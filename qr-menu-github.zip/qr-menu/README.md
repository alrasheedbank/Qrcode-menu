# QR Menü (GitHub Pages uyumlu demo)

Sunucu gerektirmeyen, tamamen statik bir QR menü sitesi.

- `index.html` → müşterinin gördüğü menü (QR buraya bağlanır)
- `admin.html` → yönetim paneli (ilk şifre: `admin123`, Ayarlar'dan değiştirin)

## Özellikler
- 2 sütunlu kare kategori kartları (kapak fotoğrafı + isim)
- Ürün: fiyat, indirimli fiyat, "Yeni" ve "Kampanya" rozetleri, açıklama, içindekiler, birden fazla fotoğraf
- **360° görüntüleyici:** ürün tabağı parmakla döndürülür, 3D açı ve otomatik dönüş
- **Masanda Gör:** telefon kamerası açılır, ürün masanın üzerine yarı saydam yerleştirilir (sürükle, iki parmakla büyüt/döndür, şeffaflık ayarı)
- Yönetim panelinden: kategori ekle/sil/sırala/kapak değiştir, ürün ekle/düzenle/gizle/sil, tüm yazılar, renk, iletişim bilgileri
- 8 demo kategori, her birinde 2 demo ürün (görseller `img/` içinde SVG olarak hazır)

## GitHub Pages'e yükleme
1. GitHub'da yeni repo açın (ör. `qr-menu`), zip içindeki **tüm dosyaları** (klasörlerle) yükleyin.
2. Repo → Settings → Pages → Source: `Deploy from a branch` → `main` / `/ (root)` → Save.
3. Birkaç dakika sonra adres: `https://KULLANICI.github.io/qr-menu/`
4. Bu adresi `admin.html` → **Yayınla & QR** sekmesine yazın, QR kodunu indirin.

> "Masanda Gör" kamera kullandığı için sitenin **HTTPS** olması gerekir; GitHub Pages zaten HTTPS'tir.

## Menüyü güncelleme (önemli)
Site statik olduğu için panelde yaptığınız değişiklikler önce **sadece o tarayıcıda taslak** olarak saklanır.
Müşterilere yansıtmak için:
1. Panel → **Yayınla & QR** → **menu.js indir**
2. GitHub'da `data/menu.js` dosyasını bu dosya ile değiştirin (Upload files / Edit) → Commit
3. 1-2 dakika sonra herkes yeni menüyü görür.

İpucu: Panelden yüklenen fotoğraflar küçültülüp `menu.js` içine gömülür. Çok fotoğraf eklerseniz dosya büyür; bu durumda fotoğrafları `img/` klasörüne yükleyip ürün formunda "yol/URL" kutusuna `img/dosya.jpg` yazabilirsiniz.

## Kendi fotoğraflarınız
En iyi sonuç için tabağı **üstten çekilmiş**, mümkünse arka planı kaldırılmış (şeffaf PNG/WebP) fotoğraflar kullanın; "Fotoğrafı daire kes" seçeneğini kapatın.

## Klasörler
```
index.html  admin.html
css/  style.css  admin.css
js/   app.js  admin.js  store.js
data/ menu.js          ← yayınlanan menü verisi
img/                    ← demo görseller
```
