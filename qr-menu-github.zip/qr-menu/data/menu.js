/* Menü verisi. Yönetim panelinden "Yayınla" ile indirdiğiniz menu.js dosyası ile bu dosyayı değiştirin. */
window.MENU_DEFAULT = {
 "version": 1,
 "updatedAt": 1795117962741,
 "settings": {
  "businessName": "Lezzet Durağı",
  "tagline": "Taze • Lezzetli • Modern",
  "logoText": "LD",
  "categoriesTitle": "Menü",
  "featuredTitle": "Öne Çıkanlar",
  "searchPlaceholder": "Menüde ara…",
  "currency": "₺",
  "accent": "#e8b04b",
  "showFeatured": true,
  "arButtonText": "Masanda Gör",
  "phone": "+90 555 000 00 00",
  "instagram": "@lezzetdurağı",
  "address": "Örnek Mah. Demo Sk. No:1",
  "wifi": "Wi-Fi şifresi: lezzet2026",
  "footerText": "Afiyet olsun! Fiyatlarımıza KDV dahildir.",
  "adminPassword": "admin123"
 },
 "categories": [
  {
   "id": "ana",
   "name": "Ana Yemekler",
   "image": "img/c-ana.svg"
  },
  {
   "id": "salata",
   "name": "Salatalar",
   "image": "img/c-salata.svg"
  },
  {
   "id": "baslangic",
   "name": "Başlangıçlar",
   "image": "img/c-baslangic.svg"
  },
  {
   "id": "tatli",
   "name": "Tatlılar",
   "image": "img/c-tatli.svg"
  },
  {
   "id": "sicak",
   "name": "Sıcak İçecekler",
   "image": "img/c-sicak.svg"
  },
  {
   "id": "soguk",
   "name": "Soğuk İçecekler",
   "image": "img/c-soguk.svg"
  },
  {
   "id": "nargile",
   "name": "Nargileler",
   "image": "img/c-nargile.svg"
  },
  {
   "id": "atistirma",
   "name": "Atıştırmalıklar",
   "image": "img/c-atistirma.svg"
  }
 ],
 "products": [
  {
   "id": "kofte",
   "categoryId": "ana",
   "name": "Izgara Köfte",
   "desc": "Közde pişmiş dana köfte; közlenmiş domates ve biberle, pilav eşliğinde servis edilir.",
   "ingredients": [
    "Dana kıyma",
    "Közlenmiş domates",
    "Sivri biber",
    "Soğan",
    "Maydanoz",
    "Baharat"
   ],
   "price": 260,
   "salePrice": 220,
   "isNew": false,
   "isCampaign": true,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-kofte.svg"
   ]
  },
  {
   "id": "antrikot",
   "categoryId": "ana",
   "name": "Dana Antrikot",
   "desc": "250 gr dinlendirilmiş antrikot, çıtır patates ve biberiye ile.",
   "ingredients": [
    "Dana antrikot",
    "Patates",
    "Biberiye",
    "Tereyağı",
    "Deniz tuzu"
   ],
   "price": 480,
   "salePrice": null,
   "isNew": true,
   "isCampaign": false,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-antrikot.svg"
   ]
  },
  {
   "id": "sezar",
   "categoryId": "salata",
   "name": "Sezar Salata",
   "desc": "Marul, parmesan, kıtır kruton ve ev yapımı sezar sos.",
   "ingredients": [
    "Göbek marul",
    "Parmesan",
    "Kruton",
    "Kiraz domates",
    "Sezar sos"
   ],
   "price": 210,
   "salePrice": null,
   "isNew": false,
   "isCampaign": false,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-sezar.svg"
   ]
  },
  {
   "id": "coban",
   "categoryId": "salata",
   "name": "Çoban Salata",
   "desc": "Taze mevsim sebzeleri, zeytinyağı ve nar ekşisi ile.",
   "ingredients": [
    "Domates",
    "Salatalık",
    "Kuru soğan",
    "Biber",
    "Maydanoz",
    "Zeytinyağı"
   ],
   "price": 130,
   "salePrice": null,
   "isNew": true,
   "isCampaign": false,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-coban.svg"
   ]
  },
  {
   "id": "humus",
   "categoryId": "baslangic",
   "name": "Humus",
   "desc": "Tahinli nohut ezmesi, pul biber ve zeytinyağı; sıcak pide ile.",
   "ingredients": [
    "Nohut",
    "Tahin",
    "Limon",
    "Sarımsak",
    "Zeytinyağı",
    "Pul biber"
   ],
   "price": 140,
   "salePrice": null,
   "isNew": false,
   "isCampaign": false,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-humus.svg"
   ]
  },
  {
   "id": "sigara",
   "categoryId": "baslangic",
   "name": "Sigara Böreği",
   "desc": "Yufka içinde beyaz peynir ve maydanoz, çıtır çıtır kızartılmış.",
   "ingredients": [
    "Yufka",
    "Beyaz peynir",
    "Maydanoz",
    "Yumurta"
   ],
   "price": 150,
   "salePrice": 125,
   "isNew": false,
   "isCampaign": true,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-sigara.svg"
   ]
  },
  {
   "id": "kunefe",
   "categoryId": "tatli",
   "name": "Fıstıklı Künefe",
   "desc": "Tel kadayıf, uzayan peynir, sıcak şerbet ve Antep fıstığı; yanında dondurma.",
   "ingredients": [
    "Tel kadayıf",
    "Künefelik peynir",
    "Şerbet",
    "Antep fıstığı",
    "Vanilyalı dondurma"
   ],
   "price": 190,
   "salePrice": null,
   "isNew": true,
   "isCampaign": false,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-kunefe.svg"
   ]
  },
  {
   "id": "cheesecake",
   "categoryId": "tatli",
   "name": "Frambuazlı Cheesecake",
   "desc": "Kremsi labne dolgusu, bisküvi tabanı ve ev yapımı frambuaz sosu.",
   "ingredients": [
    "Labne",
    "Krema",
    "Bisküvi",
    "Frambuaz",
    "Nane"
   ],
   "price": 170,
   "salePrice": null,
   "isNew": false,
   "isCampaign": false,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-cheesecake.svg"
   ]
  },
  {
   "id": "kahve",
   "categoryId": "sicak",
   "name": "Türk Kahvesi",
   "desc": "Közde bakır cezvede, orta şekerli seçenekleriyle; lokum ikramıyla.",
   "ingredients": [
    "Türk kahvesi",
    "Su",
    "Şeker (isteğe bağlı)",
    "Lokum"
   ],
   "price": 80,
   "salePrice": null,
   "isNew": false,
   "isCampaign": false,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-kahve.svg"
   ]
  },
  {
   "id": "cay",
   "categoryId": "sicak",
   "name": "Demlik Çay",
   "desc": "Taze demlenmiş siyah çay, ince belli bardakta.",
   "ingredients": [
    "Rize çayı",
    "Su",
    "Kesme şeker"
   ],
   "price": 60,
   "salePrice": 45,
   "isNew": false,
   "isCampaign": true,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-cay.svg"
   ]
  },
  {
   "id": "limonata",
   "categoryId": "soguk",
   "name": "Naneli Limonata",
   "desc": "Taze sıkılmış limon, nane ve bol buz ile ev yapımı limonata.",
   "ingredients": [
    "Limon",
    "Nane",
    "Şeker",
    "Buz",
    "Soda"
   ],
   "price": 95,
   "salePrice": null,
   "isNew": false,
   "isCampaign": false,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-limonata.svg"
   ]
  },
  {
   "id": "latte",
   "categoryId": "soguk",
   "name": "Buzlu Latte",
   "desc": "Çift shot espresso, soğuk süt ve buz.",
   "ingredients": [
    "Espresso",
    "Süt",
    "Buz",
    "Vanilya şurubu"
   ],
   "price": 110,
   "salePrice": null,
   "isNew": true,
   "isCampaign": false,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-latte.svg"
   ]
  },
  {
   "id": "elma",
   "categoryId": "nargile",
   "name": "Çift Elma Nargile",
   "desc": "Klasik çift elma aroması, yumuşak içim.",
   "ingredients": [
    "Çift elma aromalı tütün",
    "Kömür",
    "Buz suyu"
   ],
   "price": 350,
   "salePrice": null,
   "isNew": false,
   "isCampaign": false,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-elma.svg"
   ]
  },
  {
   "id": "nane",
   "categoryId": "nargile",
   "name": "Nane Limon Nargile",
   "desc": "Ferah nane ve limon karışımı, yaz içimi.",
   "ingredients": [
    "Nane aromalı tütün",
    "Limon aroması",
    "Kömür",
    "Buz suyu"
   ],
   "price": 380,
   "salePrice": 330,
   "isNew": false,
   "isCampaign": true,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-nane.svg"
   ]
  },
  {
   "id": "patates",
   "categoryId": "atistirma",
   "name": "Çıtır Patates",
   "desc": "Baharatlı, çıtır patates kızartması; ketçap ve mayonez ile.",
   "ingredients": [
    "Patates",
    "Baharat",
    "Deniz tuzu"
   ],
   "price": 120,
   "salePrice": null,
   "isNew": false,
   "isCampaign": false,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-patates.svg"
   ]
  },
  {
   "id": "nugget",
   "categoryId": "atistirma",
   "name": "Tavuk Nugget",
   "desc": "Çıtır panelenmiş tavuk parçaları, iki çeşit sosla.",
   "ingredients": [
    "Tavuk göğsü",
    "Galeta unu",
    "Baharat",
    "Sos"
   ],
   "price": 160,
   "salePrice": null,
   "isNew": true,
   "isCampaign": false,
   "available": true,
   "arEnabled": true,
   "round": true,
   "images": [
    "img/p-nugget.svg"
   ]
  }
 ]
};
