(function () {
  'use strict';
  var D = Store.get();
  var tab = 'products';
  var filterCat = '';
  var root = document.getElementById('root');
  var modal = document.getElementById('modal');
  var toastEl = document.getElementById('toast');

  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var uid = function () { return 'x' + Math.random().toString(36).slice(2, 9); };
  var catName = function (id) { var c = D.categories.filter(function (x) { return x.id === id; })[0]; return c ? c.name : '—'; };
  var $ = function (s, r) { return (r || document).querySelector(s); };

  function toast(t) { toastEl.textContent = t; toastEl.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(function () { toastEl.classList.remove('on'); }, 1800); }
  function save(msg) { if (Store.save(D)) { toast(msg || 'Kaydedildi ✓'); return true; } return false; }

  /* ---------- görsel yükleme (küçült + base64) ---------- */
  function fileToDataUrl(file, max, cb) {
    var fr = new FileReader();
    fr.onload = function () {
      var im = new Image();
      im.onload = function () {
        var k = Math.min(1, max / Math.max(im.width, im.height));
        var c = document.createElement('canvas'); c.width = Math.round(im.width * k); c.height = Math.round(im.height * k);
        c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
        var out = c.toDataURL('image/webp', 0.85);
        if (out.indexOf('data:image/webp') !== 0) out = c.toDataURL('image/jpeg', 0.85);
        cb(out);
      };
      im.onerror = function () { toast('Görsel okunamadı'); };
      im.src = fr.result;
    };
    fr.readAsDataURL(file);
  }

  /* ---------- giriş ---------- */
  function renderLogin() {
    root.innerHTML = '<div class="login"><div class="box"><h1>🔐 Yönetim Paneli</h1><p>' + esc(D.settings.businessName) + '</p>' +
      '<label class="f"><input id="pw" type="password" placeholder="Şifre" autofocus></label><button class="btn pri" id="go" style="width:100%">Giriş</button>' +
      '<p style="margin-top:14px;font-size:12px">İlk şifre: <b>admin123</b> (Ayarlar sekmesinden değiştirin)</p></div></div>';
    var go = function () { if ($('#pw').value === D.settings.adminPassword) { sessionStorage.setItem('qm_auth', '1'); render(); } else { toast('Şifre yanlış'); } };
    $('#go').onclick = go; $('#pw').onkeydown = function (e) { if (e.key === 'Enter') go(); };
  }

  /* ---------- ana çerçeve ---------- */
  function render() {
    if (sessionStorage.getItem('qm_auth') !== '1') return renderLogin();
    var tabs = [['products', '🍽️ Ürünler'], ['categories', '🗂️ Kategoriler'], ['settings', '⚙️ Site Ayarları'], ['publish', '🚀 Yayınla & QR']];
    root.innerHTML = '<div class="topbar"><h1>' + esc(D.settings.businessName) + ' • Yönetim</h1>' +
      (Store.hasDraft() ? '<span class="badge-dirty" title="Değişiklikler bu tarayıcıda. Herkese yayınlamak için Yayınla sekmesine bakın.">Taslak (yayınlanmadı)</span>' : '') +
      '<a class="btn" href="index.html" target="_blank">Menüyü Gör ↗</a><button class="btn" id="logout">Çıkış</button></div>' +
      '<div class="wrap"><div class="tabs">' + tabs.map(function (t) { return '<button class="tab' + (t[0] === tab ? ' on' : '') + '" data-tab="' + t[0] + '">' + t[1] + '</button>'; }).join('') + '</div><div id="tabbody"></div></div>';
    $('#logout').onclick = function () { sessionStorage.removeItem('qm_auth'); render(); };
    [].forEach.call(document.querySelectorAll('[data-tab]'), function (b) { b.onclick = function () { tab = b.dataset.tab; render(); }; });
    var body = $('#tabbody');
    ({ products: tabProducts, categories: tabCategories, settings: tabSettings, publish: tabPublish })[tab](body);
  }

  /* ---------- modal ---------- */
  function openModal(html) { modal.innerHTML = '<div class="bg"><div class="dlg">' + html + '</div></div>'; modal.firstChild.addEventListener('mousedown', function (e) { if (e.target === modal.firstChild) closeModal(); }); }
  function closeModal() { modal.innerHTML = ''; }

  /* ---------- ürünler ---------- */
  function tabProducts(body) {
    var list = D.products.filter(function (p) { return !filterCat || p.categoryId === filterCat; });
    body.innerHTML = '<div class="toolbar"><select id="fc" class="btn"><option value="">Tüm kategoriler</option>' + D.categories.map(function (c) { return '<option value="' + esc(c.id) + '"' + (c.id === filterCat ? ' selected' : '') + '>' + esc(c.name) + '</option>'; }).join('') +
      '</select><button class="btn acc" id="addp">+ Yeni Ürün</button></div>' +
      (list.length ? list.map(function (p) {
        return '<div class="item"><img src="' + esc(p.images[0] || '') + '" alt=""><div class="meta"><b>' + esc(p.name) + '</b><small>' + esc(catName(p.categoryId)) + ' • ' +
          (p.salePrice ? '<s>' + p.price + '</s> <b style="display:inline">' + p.salePrice + '</b>' : p.price) + ' ' + esc(D.settings.currency) + '</small><div style="margin-top:4px">' +
          (p.isNew ? '<span class="tag n">Yeni</span>' : '') + (p.isCampaign ? '<span class="tag c">Kampanya</span>' : '') + (p.available === false ? '<span class="tag x">Tükendi / Gizli</span>' : '') + (p.arEnabled ? '<span class="tag">AR</span>' : '') + '</div></div>' +
          '<div class="acts"><button class="btn sm" data-edit="' + esc(p.id) + '">Düzenle</button><button class="btn sm" data-tog="' + esc(p.id) + '">' + (p.available === false ? 'Göster' : 'Gizle') + '</button><button class="btn sm del" data-del="' + esc(p.id) + '">Sil</button></div></div>';
      }).join('') : '<div class="card">Bu kategoride ürün yok.</div>');
    $('#fc').onchange = function (e) { filterCat = e.target.value; render(); };
    $('#addp').onclick = function () { if (!D.categories.length) return toast('Önce kategori ekleyin'); productForm(null); };
    body.onclick = function (e) {
      var b = e.target.closest('button'); if (!b) return;
      if (b.dataset.edit) productForm(b.dataset.edit);
      if (b.dataset.tog) { var p = D.products.filter(function (x) { return x.id === b.dataset.tog; })[0]; p.available = p.available === false; save(); render(); }
      if (b.dataset.del && confirm('Bu ürün silinsin mi?')) { D.products = D.products.filter(function (x) { return x.id !== b.dataset.del; }); save('Silindi'); render(); }
    };
  }

  function productForm(id) {
    var p = id ? JSON.parse(JSON.stringify(D.products.filter(function (x) { return x.id === id; })[0])) : { id: uid(), categoryId: filterCat || D.categories[0].id, name: '', desc: '', ingredients: [], price: '', salePrice: '', isNew: false, isCampaign: false, available: true, arEnabled: true, round: true, images: [] };
    function paintImgs() {
      $('#imgs').innerHTML = p.images.map(function (s, i) {
        return '<div class="im' + (i ? '' : ' main') + '"><img src="' + esc(s) + '" alt=""><button class="x" data-rm="' + i + '" type="button">×</button>' + (i ? '<button class="mk" data-mk="' + i + '" type="button">Kapak yap</button>' : '<button class="mk" type="button" disabled>Kapak</button>') + '</div>';
      }).join('') || '<small style="color:#999">Henüz fotoğraf yok</small>';
    }
    openModal('<h2>' + (id ? 'Ürünü Düzenle' : 'Yeni Ürün') + '</h2>' +
      '<div class="grid2"><label class="f">Ürün adı<input id="f-name" value="' + esc(p.name) + '"></label><label class="f">Kategori<select id="f-cat">' + D.categories.map(function (c) { return '<option value="' + esc(c.id) + '"' + (c.id === p.categoryId ? ' selected' : '') + '>' + esc(c.name) + '</option>'; }).join('') + '</select></label>' +
      '<label class="f">Fiyat<input id="f-price" type="number" step="0.01" min="0" value="' + esc(p.price) + '"></label><label class="f">İndirimli fiyat (boş = yok)<input id="f-sale" type="number" step="0.01" min="0" value="' + esc(p.salePrice || '') + '"></label></div>' +
      '<label class="f">Açıklama<textarea id="f-desc">' + esc(p.desc) + '</textarea></label>' +
      '<label class="f">İçindekiler (virgülle ayırın)<input id="f-ing" value="' + esc(p.ingredients.join(', ')) + '"></label>' +
      '<div class="checks"><label><input type="checkbox" id="f-new"' + (p.isNew ? ' checked' : '') + '> Yeni ürün</label><label><input type="checkbox" id="f-camp"' + (p.isCampaign ? ' checked' : '') + '> Kampanyalı ürün</label><label><input type="checkbox" id="f-av"' + (p.available !== false ? ' checked' : '') + '> Satışta (menüde görünür)</label>' +
      '<label><input type="checkbox" id="f-ar"' + (p.arEnabled ? ' checked' : '') + '> "Masanda Gör" butonu</label><label><input type="checkbox" id="f-round"' + (p.round ? ' checked' : '') + '> Fotoğrafı daire (tabak) kes</label></div>' +
      '<b style="font-size:13px;color:#7b7266">Fotoğraflar (ilki kapak olur)</b><div class="imgs" id="imgs" style="margin-top:8px"></div>' +
      '<div class="row" style="margin-bottom:16px;flex-wrap:wrap"><label class="btn sm">+ Fotoğraf yükle<input id="f-file" type="file" accept="image/*" multiple hidden></label><input id="f-url" placeholder="veya yol/URL: img/benim.jpg" style="flex:1;min-width:160px;padding:7px 10px;border:1px solid #e6e0d6;border-radius:10px"><button class="btn sm" id="f-addurl" type="button">Ekle</button></div>' +
      '<div class="row" style="justify-content:flex-end"><button class="btn" id="f-cancel">İptal</button><button class="btn pri" id="f-save">Kaydet</button></div>');
    paintImgs();
    $('#imgs').onclick = function (e) {
      var b = e.target.closest('button'); if (!b) return;
      if (b.dataset.rm) p.images.splice(+b.dataset.rm, 1);
      if (b.dataset.mk) { var s = p.images.splice(+b.dataset.mk, 1)[0]; p.images.unshift(s); }
      paintImgs();
    };
    $('#f-file').onchange = function (e) { [].forEach.call(e.target.files, function (f) { fileToDataUrl(f, 900, function (u) { p.images.push(u); paintImgs(); }); }); e.target.value = ''; };
    $('#f-addurl').onclick = function () { var u = $('#f-url').value.trim(); if (u) { p.images.push(u); $('#f-url').value = ''; paintImgs(); } };
    $('#f-cancel').onclick = closeModal;
    $('#f-save').onclick = function () {
      var name = $('#f-name').value.trim(); if (!name) return toast('Ürün adı gerekli');
      p.name = name; p.categoryId = $('#f-cat').value; p.price = parseFloat($('#f-price').value) || 0;
      var sv = parseFloat($('#f-sale').value); p.salePrice = sv > 0 ? sv : null;
      p.desc = $('#f-desc').value.trim(); p.ingredients = $('#f-ing').value.split(',').map(function (x) { return x.trim(); }).filter(Boolean);
      p.isNew = $('#f-new').checked; p.isCampaign = $('#f-camp').checked; p.available = $('#f-av').checked; p.arEnabled = $('#f-ar').checked; p.round = $('#f-round').checked;
      var i = D.products.map(function (x) { return x.id; }).indexOf(p.id);
      if (i < 0) D.products.push(p); else D.products[i] = p;
      if (save()) { closeModal(); render(); }
    };
  }

  /* ---------- kategoriler ---------- */
  function tabCategories(body) {
    body.innerHTML = '<div class="toolbar"><span style="color:#7b7266">Sıralamayı ▲▼ ile değiştirin. Menüde 2 sütunlu kare kartlar olarak görünür.</span><button class="btn acc" id="addc">+ Yeni Kategori</button></div>' +
      D.categories.map(function (c, i) {
        var n = D.products.filter(function (p) { return p.categoryId === c.id; }).length;
        return '<div class="item"><img src="' + esc(c.image) + '" alt=""><div class="meta"><b>' + esc(c.name) + '</b><small>' + n + ' ürün</small></div><div class="acts">' +
          '<button class="btn sm" data-up="' + i + '"' + (i ? '' : ' disabled') + '>▲</button><button class="btn sm" data-dn="' + i + '"' + (i < D.categories.length - 1 ? '' : ' disabled') + '>▼</button>' +
          '<button class="btn sm" data-edit="' + esc(c.id) + '">Düzenle</button><button class="btn sm del" data-del="' + esc(c.id) + '">Sil</button></div></div>';
      }).join('');
    $('#addc').onclick = function () { catForm(null); };
    body.onclick = function (e) {
      var b = e.target.closest('button'); if (!b || b.disabled) return;
      var mv = function (i, d) { var t = D.categories[i]; D.categories[i] = D.categories[i + d]; D.categories[i + d] = t; save(); render(); };
      if (b.dataset.up) mv(+b.dataset.up, -1);
      if (b.dataset.dn) mv(+b.dataset.dn, 1);
      if (b.dataset.edit) catForm(b.dataset.edit);
      if (b.dataset.del) {
        var n = D.products.filter(function (p) { return p.categoryId === b.dataset.del; }).length;
        if (confirm('Kategori silinsin mi?' + (n ? ' İçindeki ' + n + ' ürün de silinecek!' : ''))) { D.categories = D.categories.filter(function (c) { return c.id !== b.dataset.del; }); D.products = D.products.filter(function (p) { return p.categoryId !== b.dataset.del; }); save('Silindi'); render(); }
      }
    };
  }
  function catForm(id) {
    var c = id ? JSON.parse(JSON.stringify(D.categories.filter(function (x) { return x.id === id; })[0])) : { id: uid(), name: '', image: '' };
    openModal('<h2>' + (id ? 'Kategoriyi Düzenle' : 'Yeni Kategori') + '</h2><label class="f">Kategori adı<input id="c-name" value="' + esc(c.name) + '"></label>' +
      '<b style="font-size:13px;color:#7b7266">Kapak fotoğrafı</b><div class="imgs" style="margin-top:8px"><div class="im main" style="width:140px;height:140px"><img id="c-prev" src="' + esc(c.image) + '" alt=""></div></div>' +
      '<div class="row" style="margin-bottom:16px;flex-wrap:wrap"><label class="btn sm">Fotoğraf yükle<input id="c-file" type="file" accept="image/*" hidden></label><input id="c-url" placeholder="veya yol/URL: img/kapak.jpg" style="flex:1;min-width:160px;padding:7px 10px;border:1px solid #e6e0d6;border-radius:10px" value="' + (c.image && c.image.indexOf('data:') !== 0 ? esc(c.image) : '') + '"></div>' +
      '<div class="row" style="justify-content:flex-end"><button class="btn" id="c-cancel">İptal</button><button class="btn pri" id="c-save">Kaydet</button></div>');
    $('#c-file').onchange = function (e) { if (e.target.files[0]) fileToDataUrl(e.target.files[0], 800, function (u) { c.image = u; $('#c-prev').src = u; $('#c-url').value = ''; }); };
    $('#c-url').oninput = function (e) { if (e.target.value.trim()) { c.image = e.target.value.trim(); $('#c-prev').src = c.image; } };
    $('#c-cancel').onclick = closeModal;
    $('#c-save').onclick = function () {
      var n = $('#c-name').value.trim(); if (!n) return toast('Kategori adı gerekli');
      c.name = n; var i = D.categories.map(function (x) { return x.id; }).indexOf(c.id);
      if (i < 0) D.categories.push(c); else D.categories[i] = c;
      if (save()) { closeModal(); render(); }
    };
  }

  /* ---------- ayarlar ---------- */
  function tabSettings(body) {
    var s = D.settings;
    var fld = function (k, label, type) { return '<label class="f">' + label + '<input data-k="' + k + '" type="' + (type || 'text') + '" value="' + esc(s[k]) + '"></label>'; };
    body.innerHTML = '<div class="card"><h3>İşletme bilgileri</h3><div class="grid2">' + fld('businessName', 'İşletme adı') + fld('tagline', 'Slogan / alt yazı') + fld('logoText', 'Logo harfleri (örn. LD)') + fld('currency', 'Para birimi') + '</div></div>' +
      '<div class="card"><h3>Menü yazıları</h3><div class="grid2">' + fld('categoriesTitle', 'Kategori bölümü başlığı') + fld('featuredTitle', 'Öne çıkanlar başlığı') + fld('searchPlaceholder', 'Arama kutusu yazısı') + fld('arButtonText', '"Masanda gör" buton yazısı') + '</div>' +
      '<div class="checks"><label><input type="checkbox" data-k="showFeatured"' + (s.showFeatured !== false ? ' checked' : '') + '> "Öne çıkanlar" bölümünü göster (yeni / kampanyalı / indirimli ürünler)</label></div></div>' +
      '<div class="card"><h3>Görünüm</h3>' + '<label class="f" style="max-width:200px">Vurgu rengi<input data-k="accent" type="color" value="' + esc(s.accent) + '"></label></div>' +
      '<div class="card"><h3>İletişim & alt bilgi</h3><div class="grid2">' + fld('phone', 'Telefon') + fld('instagram', 'Instagram') + fld('address', 'Adres') + fld('wifi', 'Wi-Fi bilgisi') + '</div>' + fld('footerText', 'Alt bilgi yazısı') + '</div>' +
      '<div class="card"><h3>Panel şifresi</h3>' + fld('adminPassword', 'Şifre') + '<small style="color:#7b7266">Not: Bu panel statik sitede çalışır; şifre yalnızca kazara girişi engeller, güvenlik katmanı değildir.</small></div>' +
      '<button class="btn pri" id="ss">Kaydet</button>';
    $('#ss').onclick = function () {
      [].forEach.call(body.querySelectorAll('[data-k]'), function (i) { s[i.dataset.k] = i.type === 'checkbox' ? i.checked : i.value; });
      if (save()) render();
    };
  }

  /* ---------- yayınla / yedek / QR ---------- */
  function download(name, text, type) { var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: type || 'text/javascript' })); a.download = name; a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000); }
  function tabPublish(body) {
    var guess = location.protocol.indexOf('http') === 0 ? location.href.replace(/admin\.html.*$/, 'index.html') : 'https://KULLANICI.github.io/REPO/';
    body.innerHTML = '<div class="note"><b>Önemli:</b> Panelde yaptığınız değişiklikler bu tarayıcıda <b>taslak</b> olarak saklanır. Müşterilerin görmesi için aşağıdaki <b>"menu.js indir"</b> butonuna basın ve indirdiğiniz dosyayı GitHub\'daki <code>data/menu.js</code> ile değiştirin (commit edin). GitHub Pages 1-2 dakikada günceller.</div>' +
      '<div class="card"><h3>1) Yayınla</h3><div class="row" style="flex-wrap:wrap"><button class="btn acc" id="dl">⬇ menu.js indir</button><span style="color:#7b7266">→ GitHub: <code>data/menu.js</code> dosyasını değiştirin</span></div>' +
      '<ol class="steps" style="margin-bottom:0"><li>GitHub\'da repoya girin → <code>data</code> klasörü → <code>menu.js</code></li><li>Kalem simgesi (Edit) yerine <b>Upload files</b> ile aynı isimli dosyayı yükleyin veya içeriği yapıştırın</li><li>Commit changes → 1-2 dk sonra menü güncellenir</li></ol></div>' +
      '<div class="card"><h3>2) QR Kod</h3><label class="f">Menü sitenizin adresi<input id="qu" value="' + esc(guess) + '"></label><div class="qr"><img id="qi" alt="QR"><div><button class="btn" id="qd">QR\'ı indir (PNG)</button><p style="color:#7b7266;max-width:320px">Adresi GitHub Pages linkinizle değiştirin (örn. <code>https://kullanici.github.io/qr-menu/</code>). QR görseli api.qrserver.com üzerinden üretilir, internet gerekir.</p></div></div></div>' +
      '<div class="card"><h3>3) Yedek / Geri yükle</h3><div class="row" style="flex-wrap:wrap"><label class="btn">⬆ menu.js içe aktar<input id="imp" type="file" accept=".js,.json,.txt" hidden></label><button class="btn del" id="rs">Taslağı sil, yayındaki menüye dön</button></div></div>';
    var qr = function () { $('#qi').src = 'https://api.qrserver.com/v1/create-qr-code/?size=480x480&margin=10&data=' + encodeURIComponent($('#qu').value); };
    qr(); $('#qu').onchange = qr;
    $('#qd').onclick = function () { var a = document.createElement('a'); a.href = $('#qi').src + '&format=png'; a.target = '_blank'; a.download = 'menu-qr.png'; a.click(); };
    $('#dl').onclick = function () { D.updatedAt = Date.now(); Store.save(D); download('menu.js', Store.exportJS(D)); toast('İndirildi — GitHub\'daki data/menu.js ile değiştirin'); };
    $('#imp').onchange = function (e) {
      var f = e.target.files[0]; if (!f) return; var fr = new FileReader();
      fr.onload = function () { try { D = Store.parseImport(fr.result); save('İçe aktarıldı'); render(); } catch (err) { toast('Hata: ' + err.message); } };
      fr.readAsText(f);
    };
    $('#rs').onclick = function () { if (confirm('Bu tarayıcıdaki taslak silinsin mi?')) { Store.reset(); D = Store.get(); toast('Sıfırlandı'); render(); } };
  }

  render();
})();
