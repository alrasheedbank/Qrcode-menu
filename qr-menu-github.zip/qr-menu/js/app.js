(function () {
  'use strict';
  var D = Store.get();
  var S = D.settings;
  var app = document.getElementById('app');
  var sheet = document.getElementById('sheet');
  var arEl = document.getElementById('ar');
  var viewer = null;      // aktif 360 görüntüleyici
  var internalNav = false;

  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var catById = function (id) { return D.categories.filter(function (c) { return c.id === id; })[0]; };
  var prodById = function (id) { return D.products.filter(function (p) { return p.id === id; })[0]; };
  var visible = function (p) { return p.available !== false; };

  function money(v) {
    var n = Number(v);
    var t = Number.isInteger(n) ? String(n) : n.toFixed(2).replace('.', ',');
    return t + ' ' + (S.currency || '₺');
  }
  function onSale(p) { return p.salePrice && Number(p.salePrice) > 0 && Number(p.salePrice) < Number(p.price); }
  function priceHtml(p) {
    return onSale(p) ? '<div class="pr"><b>' + money(p.salePrice) + '</b><s>' + money(p.price) + '</s></div>' : '<div class="pr"><b>' + money(p.price) + '</b></div>';
  }
  function badges(p) {
    var h = '';
    if (p.isNew) h += '<span class="badge new">Yeni</span>';
    if (p.isCampaign) h += '<span class="badge camp">Kampanya</span>';
    if (onSale(p)) h += '<span class="badge off">%' + Math.round((1 - p.salePrice / p.price) * 100) + ' İndirim</span>';
    return h ? '<div class="badges">' + h + '</div>' : '';
  }
  function mainImg(p) { return p.images && p.images[0] ? p.images[0] : ''; }
  function catImg(c) { return c.image || ''; }

  /* ---------- tema ---------- */
  function applyTheme() {
    document.documentElement.style.setProperty('--accent', S.accent || '#e8b04b');
    document.title = (S.businessName || 'Menü') + ' • Menü';
  }

  /* ---------- sayfalar ---------- */
  var icons = {
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
    back: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"/></svg>',
    arrow: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M7 17 17 7M8 7h9v9"/></svg>',
    cube: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="m12 2 9 5v10l-9 5-9-5V7z"/><path d="m3 7 9 5 9-5M12 12v10"/></svg>'
  };

  function productRow(p, i) {
    var img = mainImg(p);
    return '<button class="row' + (visible(p) ? '' : ' out') + '" data-p="' + esc(p.id) + '" style="animation-delay:' + (i * 55) + 'ms">' +
      '<div class="ph">' + (img ? '<img class="' + (p.round ? 'ph-round' : '') + '" src="' + esc(img) + '" alt="" loading="lazy">' : '') + '</div>' +
      '<div class="info"><h3>' + esc(p.name) + '</h3><p>' + esc(p.desc) + '</p>' + badges(p) +
      '<div class="foot">' + priceHtml(p) + (p.arEnabled && img ? '<span class="ar-tag">' + icons.cube + ' 360° • AR</span>' : '') + '</div></div></button>';
  }

  function footer() {
    var l = [];
    if (S.phone) l.push('📞 ' + esc(S.phone));
    if (S.instagram) l.push('📷 ' + esc(S.instagram));
    if (S.wifi) l.push('📶 ' + esc(S.wifi));
    return '<footer>' + (l.length ? '<div class="ft-links">' + l.map(function (x) { return '<span>' + x + '</span>'; }).join('') + '</div>' : '') +
      (S.address ? esc(S.address) + '<br>' : '') + esc(S.footerText || '') + '</footer>';
  }

  function renderHome() {
    var feat = D.products.filter(function (p) { return visible(p) && (p.isNew || p.isCampaign || onSale(p)); });
    app.innerHTML =
      '<div class="hero"><div class="logo">' + esc(S.logoText || (S.businessName || 'M').slice(0, 2)) + '</div><div><h1>' + esc(S.businessName) + '</h1><p>' + esc(S.tagline) + '</p></div></div>' +
      '<div class="search">' + icons.search + '<input id="q" type="search" placeholder="' + esc(S.searchPlaceholder) + '" autocomplete="off"></div>' +
      '<div id="home-body">' + homeBody(feat) + '</div>' + footer();
    document.getElementById('q').addEventListener('input', function (e) {
      var q = e.target.value.trim().toLowerCase();
      var box = document.getElementById('home-body');
      if (!q) { box.innerHTML = homeBody(feat); return; }
      var res = D.products.filter(function (p) {
        return visible(p) && (p.name + ' ' + p.desc + ' ' + p.ingredients.join(' ')).toLowerCase().indexOf(q.replace(/İ/g, 'i')) > -1;
      });
      box.innerHTML = res.length ? '<div class="list">' + res.map(productRow).join('') + '</div>' : '<div class="empty">Sonuç bulunamadı</div>';
    });
  }

  function homeBody(feat) {
    var h = '';
    if (S.showFeatured !== false && feat.length) {
      h += '<div class="sec-title"><h2>' + esc(S.featuredTitle) + '</h2></div><div class="rail">' + feat.map(function (p, i) {
        return '<button class="fcard" data-p="' + esc(p.id) + '" style="animation-delay:' + (i * 70) + 'ms"><div class="ph">' + badges(p) + '<img src="' + esc(mainImg(p)) + '" alt=""></div><b>' + esc(p.name) + '</b>' + priceHtml(p).replace('class="pr"', 'class="pr"') + '</button>';
      }).join('') + '</div>';
    }
    h += '<div class="sec-title"><h2>' + esc(S.categoriesTitle) + '</h2><span>' + D.categories.length + ' kategori</span></div><div class="cat-grid">' +
      D.categories.map(function (c, i) {
        var n = D.products.filter(function (p) { return p.categoryId === c.id && visible(p); }).length;
        return '<button class="cat" data-c="' + esc(c.id) + '" style="animation-delay:' + (i * 70) + 'ms"><img src="' + esc(catImg(c)) + '" alt="" loading="lazy"><span class="arrow">' + icons.arrow + '</span><span class="lbl"><b>' + esc(c.name) + '</b><small>' + n + ' ürün</small></span></button>';
      }).join('') + '</div>';
    return h;
  }

  function renderCategory(id) {
    var c = catById(id);
    if (!c) { location.hash = '#/'; return; }
    var items = D.products.filter(function (p) { return p.categoryId === id; });
    app.innerHTML =
      '<div class="bar"><div class="bar-row"><button class="back" data-back aria-label="Geri">' + icons.back + '</button><h2>' + esc(c.name) + '</h2></div>' +
      '<div class="chips" id="chips">' + D.categories.map(function (x) { return '<button class="chip' + (x.id === id ? ' on' : '') + '" data-c="' + esc(x.id) + '">' + esc(x.name) + '</button>'; }).join('') + '</div></div>' +
      '<div class="list">' + (items.length ? items.map(productRow).join('') : '<div class="empty">Bu kategoride henüz ürün yok</div>') + '</div>' + footer();
    var on = app.querySelector('.chip.on');
    if (on && on.scrollIntoView) on.scrollIntoView({ inline: 'center', block: 'nearest' });
    window.scrollTo(0, 0);
  }

  /* ---------- 360° görüntüleyici ---------- */
  function mountViewer(host, p) {
    if (viewer) viewer.destroy();
    var layers = 9, imgs = p.images || [];
    var src = imgs[0] || '';
    var html = '<div class="stage" id="stage"><div class="disc tilting ' + (p.round ? 'round' : '') + '" id="disc">';
    for (var i = 0; i < layers; i++) html += '<img src="' + esc(src) + '" draggable="false" alt="" style="transform:translateZ(' + (-i * 2.4) + 'px);' + (i ? 'filter:brightness(' + (0.62 - i * 0.04).toFixed(2) + ')' : '') + '">';
    html += '</div><div class="floor"></div></div><div class="hint360">↔ Sürükleyerek 360° döndür</div>' +
      '<div class="vctl"><button class="vbtn on" id="v-spin">⟳ Otomatik</button><button class="vbtn on" id="v-tilt">◢ 3D Açı</button></div>';
    host.innerHTML = html;
    var disc = host.querySelector('#disc'), stage = host.querySelector('#stage');
    var rot = 0, tilt = 50, auto = true, drag = false, lastX = 0, resume = null, raf, last = performance.now();
    function apply() { disc.style.setProperty('--rot', rot + 'deg'); disc.style.setProperty('--tilt', tilt + 'deg'); }
    function loop(t) { var dt = (t - last) / 1000; last = t; if (auto && !drag) { rot += 22 * dt; apply(); } raf = requestAnimationFrame(loop); }
    apply(); raf = requestAnimationFrame(loop);
    setTimeout(function () { disc.classList.remove('tilting'); }, 600);
    stage.addEventListener('pointerdown', function (e) { drag = true; lastX = e.clientX; stage.setPointerCapture(e.pointerId); clearTimeout(resume); host.querySelector('.hint360').style.opacity = 0; });
    stage.addEventListener('pointermove', function (e) { if (!drag) return; rot += (e.clientX - lastX) * 0.7; lastX = e.clientX; apply(); });
    function up() { drag = false; var b = host.querySelector('#v-spin'); resume = setTimeout(function () { if (b.classList.contains('on')) auto = true; }, 2500); }
    stage.addEventListener('pointerup', up); stage.addEventListener('pointercancel', up);
    host.querySelector('#v-spin').onclick = function (e) { auto = !auto; e.currentTarget.classList.toggle('on', auto); };
    host.querySelector('#v-tilt').onclick = function (e) {
      var on = e.currentTarget.classList.toggle('on'); tilt = on ? 50 : 0; disc.classList.add('tilting'); apply(); setTimeout(function () { disc.classList.remove('tilting'); }, 600);
    };
    viewer = {
      setSrc: function (s) { [].forEach.call(disc.querySelectorAll('img'), function (im) { im.src = s; }); },
      destroy: function () { cancelAnimationFrame(raf); clearTimeout(resume); viewer = null; }
    };
  }

  /* ---------- ürün detay ---------- */
  function openSheet(id) {
    var p = prodById(id);
    if (!p) return;
    var img = mainImg(p);
    var thumbs = (p.images || []).length > 1 ? '<div class="thumbs">' + p.images.map(function (s, i) { return '<button class="thumb' + (i ? '' : ' on') + '" data-img="' + esc(s) + '"><img src="' + esc(s) + '" alt=""></button>'; }).join('') + '</div>' : '';
    sheet.innerHTML = '<div class="sheet-bg" data-close></div><div class="sheet"><div class="grab"></div><button class="close" data-close aria-label="Kapat">✕</button>' +
      (img ? '<div class="viewer" id="viewer"></div>' + thumbs : '') +
      '<div class="pbody">' + badges(p) + '<h2>' + esc(p.name) + '</h2>' + priceHtml(p) + (p.desc ? '<p>' + esc(p.desc) + '</p>' : '') +
      (p.ingredients.length ? '<h4>İçindekiler</h4><div class="ing">' + p.ingredients.map(function (x) { return '<span>' + esc(x) + '</span>'; }).join('') + '</div>' : '') +
      (p.arEnabled && img ? '<button class="ar-btn" data-ar="' + esc(p.id) + '">' + icons.cube + ' ' + esc(S.arButtonText || 'Masanda Gör') + '</button>' : '') + '</div></div>';
    sheet.classList.add('on');
    document.body.style.overflow = 'hidden';
    if (img) mountViewer(document.getElementById('viewer'), p);
    requestAnimationFrame(function () { sheet.classList.add('on'); });
  }
  function closeSheetUI() {
    if (viewer) viewer.destroy();
    sheet.classList.remove('on');
    document.body.style.overflow = '';
    setTimeout(function () { if (!sheet.classList.contains('on')) sheet.innerHTML = ''; }, 500);
  }

  /* ---------- Masanda gör (kamera + yerleştirme) ---------- */
  var arStream = null;
  function openAR(id) {
    var p = prodById(id); if (!p) return;
    var src = mainImg(p);
    arEl.innerHTML = '<div class="nocam"></div><video playsinline muted autoplay></video><div class="grid"></div>' +
      '<div class="item ' + (p.round ? 'round' : '') + '" id="ar-item"><img src="' + esc(src) + '" alt=""></div>' +
      '<div class="top"><b>' + esc(p.name) + '</b><button id="ar-close" aria-label="Kapat">✕</button></div>' +
      '<div class="tip" id="ar-tip">Kamerayı masanıza doğrultun • Ürünü sürükleyin, iki parmakla büyütün/döndürün</div>' +
      '<div class="panel"><label><span>Boyut</span><input type="range" id="ar-size" min="30" max="260" value="100"></label>' +
      '<label><span>Döndür</span><input type="range" id="ar-rot" min="0" max="360" value="0"></label>' +
      '<label><span>Şeffaflık</span><input type="range" id="ar-op" min="35" max="100" value="94"></label></div>';
    arEl.classList.add('on');
    var video = arEl.querySelector('video'), nocam = arEl.querySelector('.nocam'), item = document.getElementById('ar-item'), tip = document.getElementById('ar-tip');
    var st = { x: innerWidth / 2, y: innerHeight * 0.5, s: 1, r: 0, o: 0.94 };
    function paint() { var w = item.offsetWidth; item.style.opacity = st.o; item.style.transform = 'translate(' + (st.x - w / 2) + 'px,' + (st.y - w / 2) + 'px) rotate(' + st.r + 'deg) scale(' + st.s + ')'; }
    paint();
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' } }, audio: false }).then(function (s) {
        arStream = s; video.srcObject = s; video.play(); nocam.style.display = 'none';
      }).catch(function () { tip.textContent = 'Kamera izni verilmedi — ürün masa dokusu üzerinde gösteriliyor. Tarayıcı ayarlarından kamera iznini açabilirsiniz.'; });
    } else tip.textContent = 'Bu cihazda kamera erişimi yok (HTTPS gerekir).';
    setTimeout(function () { tip.style.opacity = 0; }, 6500);

    // dokunma: sürükle + iki parmak ölçek/döndürme
    var ptrs = {}, startD = 0, startA = 0, startS = 1, startR = 0;
    item.addEventListener('pointerdown', function (e) { item.setPointerCapture(e.pointerId); ptrs[e.pointerId] = { x: e.clientX, y: e.clientY }; var k = Object.keys(ptrs); if (k.length === 2) { var a = ptrs[k[0]], b = ptrs[k[1]]; startD = Math.hypot(a.x - b.x, a.y - b.y); startA = Math.atan2(b.y - a.y, b.x - a.x); startS = st.s; startR = st.r; } });
    item.addEventListener('pointermove', function (e) {
      if (!ptrs[e.pointerId]) return;
      var k = Object.keys(ptrs);
      if (k.length === 1) { st.x += e.clientX - ptrs[e.pointerId].x; st.y += e.clientY - ptrs[e.pointerId].y; }
      ptrs[e.pointerId] = { x: e.clientX, y: e.clientY };
      if (k.length === 2) { var a = ptrs[k[0]], b = ptrs[k[1]]; st.s = Math.min(2.6, Math.max(.3, startS * Math.hypot(a.x - b.x, a.y - b.y) / startD)); st.r = startR + (Math.atan2(b.y - a.y, b.x - a.x) - startA) * 180 / Math.PI; syncUI(); }
      paint();
    });
    function end(e) { delete ptrs[e.pointerId]; }
    item.addEventListener('pointerup', end); item.addEventListener('pointercancel', end);
    function syncUI() { document.getElementById('ar-size').value = st.s * 100; document.getElementById('ar-rot').value = ((st.r % 360) + 360) % 360; }
    document.getElementById('ar-size').oninput = function (e) { st.s = e.target.value / 100; paint(); };
    document.getElementById('ar-rot').oninput = function (e) { st.r = +e.target.value; paint(); };
    document.getElementById('ar-op').oninput = function (e) { st.o = e.target.value / 100; paint(); };
    document.getElementById('ar-close').onclick = closeAR;
  }
  function closeAR() {
    if (arStream) { arStream.getTracks().forEach(function (t) { t.stop(); }); arStream = null; }
    arEl.classList.remove('on'); arEl.innerHTML = '';
  }

  /* ---------- yönlendirme ---------- */
  function route() {
    var h = location.hash || '#/';
    var m;
    if ((m = h.match(/^#\/p\/(.+)$/))) {
      var p = prodById(decodeURIComponent(m[1]));
      if (!p) { location.hash = '#/'; return; }
      if (!app.innerHTML) renderCategory(p.categoryId);
      openSheet(p.id);
      return;
    }
    closeSheetUI();
    if ((m = h.match(/^#\/c\/(.+)$/))) renderCategory(decodeURIComponent(m[1]));
    else renderHome();
  }
  function go(hash) { internalNav = true; location.hash = hash; }

  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-p],[data-c],[data-back],[data-close],[data-ar],[data-img]');
    if (!t) return;
    if (t.dataset.ar) { openAR(t.dataset.ar); return; }
    if (t.dataset.img !== undefined && t.classList.contains('thumb')) {
      [].forEach.call(document.querySelectorAll('.thumb'), function (x) { x.classList.remove('on'); }); t.classList.add('on');
      if (viewer) viewer.setSrc(t.dataset.img); return;
    }
    if (t.dataset.p) { go('#/p/' + encodeURIComponent(t.dataset.p)); return; }
    if (t.dataset.c) { go('#/c/' + encodeURIComponent(t.dataset.c)); return; }
    if (t.hasAttribute('data-back')) { internalNav ? history.back() : (location.hash = '#/'); return; }
    if (t.hasAttribute('data-close')) {
      if (internalNav) history.back(); else { var m = (location.hash.match(/^#\/p\/(.+)$/) || [])[1]; var p = m && prodById(decodeURIComponent(m)); location.hash = p ? '#/c/' + p.categoryId : '#/'; }
    }
  });
  window.addEventListener('hashchange', route);
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { if (arEl.classList.contains('on')) closeAR(); else if (sheet.classList.contains('on')) history.back(); } });

  applyTheme();
  route();
})();
