/* Veri katmanı: data/menu.js (GitHub'daki yayınlanmış veri) + tarayıcıdaki taslak (localStorage) */
window.Store = (function () {
  var KEY = 'qrmenu_draft_v1';
  var DEFAULT_SETTINGS = {
    businessName: 'Menü', tagline: '', logoText: 'M', categoriesTitle: 'Menü', featuredTitle: 'Öne Çıkanlar',
    searchPlaceholder: 'Menüde ara…', currency: '₺', accent: '#e8b04b', showFeatured: true, arButtonText: 'Masanda Gör',
    phone: '', instagram: '', address: '', wifi: '', footerText: '', adminPassword: 'admin123'
  };

  function clone(o) { return JSON.parse(JSON.stringify(o)); }

  function normalize(d) {
    d = d || {};
    d.settings = Object.assign({}, DEFAULT_SETTINGS, d.settings || {});
    d.categories = d.categories || [];
    d.products = (d.products || []).map(function (p) {
      p.images = p.images || [];
      p.ingredients = p.ingredients || [];
      if (p.available === undefined) p.available = true;
      if (p.arEnabled === undefined) p.arEnabled = true;
      if (p.round === undefined) p.round = true;
      return p;
    });
    d.updatedAt = d.updatedAt || 0;
    return d;
  }

  function published() { return normalize(clone(window.MENU_DEFAULT || {})); }

  function get() {
    var pub = published(), local = null;
    try { local = JSON.parse(localStorage.getItem(KEY)); } catch (e) { }
    if (local && (local.updatedAt || 0) >= (pub.updatedAt || 0)) return normalize(local);
    if (local) { try { localStorage.removeItem(KEY); } catch (e) { } }
    return pub;
  }

  function hasDraft() { try { return !!localStorage.getItem(KEY); } catch (e) { return false; } }

  function save(d) {
    d.updatedAt = Date.now();
    try { localStorage.setItem(KEY, JSON.stringify(d)); return true; }
    catch (e) { alert('Kayıt başarısız: tarayıcı hafızası dolu olabilir. Daha küçük fotoğraflar kullanın veya fotoğrafları img/ klasörüne koyup yolunu yazın.'); return false; }
  }

  function reset() { try { localStorage.removeItem(KEY); } catch (e) { } }

  function exportJS(d) {
    return '/* Menü verisi - yönetim panelinden dışa aktarıldı */\nwindow.MENU_DEFAULT = ' + JSON.stringify(d, null, 1) + ';\n';
  }

  function parseImport(text) {
    var i = text.indexOf('{'), j = text.lastIndexOf('}');
    if (i < 0 || j < 0) throw new Error('Geçersiz dosya');
    var d = JSON.parse(text.slice(i, j + 1));
    if (!d.categories || !d.products) throw new Error('Menü verisi bulunamadı');
    return normalize(d);
  }

  return { get: get, save: save, reset: reset, hasDraft: hasDraft, exportJS: exportJS, parseImport: parseImport, normalize: normalize, defaults: DEFAULT_SETTINGS };
})();
